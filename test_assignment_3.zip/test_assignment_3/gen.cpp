#include <bits/stdc++.h>
using namespace std;

int rand(int a, int b) {
    return a + rand() % (b - a + 1);
}

int main(int argc, char* argv[]) {
    srand(atoi(argv[1])); // atoi(s) converts an array of chars to int
   
    int a = rand(2, 7), b = rand(2, 8), n = rand(2, 10);
    // int a = rand(2, 200), b = rand(2, 200), n = rand(2, 40000);
    
    if(a*b < n+2)
    	n = 1;
    printf("%d %d %d\n",a, b, n);
    set<int> used;
    for(int i = 0; i < n; ++i) {
        int x;
        do {
            x = rand(1, a*b-2);
        } while(used.count(x));
        used.insert(x);
    }
    for(auto it: used){
    	cout<< it % a << " ";
    }
    cout<<endl;
    for(auto it: used)
    	cout<< it / a << " ";
    cout<<endl;

    cout<<"0 0 "<<a-1<<" "<<b-1<<endl;
}

   