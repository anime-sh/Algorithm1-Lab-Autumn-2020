#!/bin/sh

gcc brute.c -o brute
g++ sol.cpp -o sol
g++ -std=c++14 gen.cpp -o gen

for((i = 1; ; ++i)); do
    echo $i
    ./gen $i > input.in
    diff -w <(./sol < input.in) <(./brute < input.in) || break
done